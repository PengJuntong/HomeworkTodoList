package com.example.homeworktodolist;


import com.example.homeworktodolist.beans.Note;

public interface NoteOperator {

    void deleteNote(Note note);

    void updateNote(Note note);
}
