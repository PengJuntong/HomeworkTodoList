package com.example.homeworktodolist

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.annotation.Nullable
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.homeworktodolist.db.TodoDbHelper
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.*

class MainActivity : AppCompatActivity() {
    private var recyclerView: RecyclerView? = null
    private var notesAdapter: NoteListAdapter? = null
    private var dbHelper: TodoDbHelper? = null
    private var database: SQLiteDatabase? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener(View.OnClickListener { //                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
            //                        .setAction("Action", null).show();
            startActivityForResult(
                Intent(this@MainActivity, NoteActivity::class.java),
                REQUEST_CODE_ADD
            )
        })
        dbHelper = TodoDbHelper(this)
        database = dbHelper!!.getWritableDatabase()
        recyclerView = findViewById(R.id.list_todo)
        recyclerView.setLayoutManager(
            LinearLayoutManager(
                this,
                LinearLayoutManager.VERTICAL, false
            )
        )
        recyclerView.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )
        notesAdapter = NoteListAdapter(object : NoteOperator() {
            fun deleteNote(note: com.byted.camp.todolist.beans.Note) {
                this@MainActivity.deleteNote(note)
            }

            fun updateNote(note: com.example.homeworktodolist.beans.Note) {
                updateNode(note)
            }
        })
        recyclerView.setAdapter(notesAdapter)
        notesAdapter.refresh(loadNotesFromDatabase())
    }

    override fun onDestroy() {
        super.onDestroy()
        database!!.close()
        database = null
        dbHelper?.close()
        dbHelper = null
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        val id = item.itemId
//        when (id) {
//            R.id.action_settings -> return true
//            R.id.action_debug -> {
//                startActivity(Intent(this, DebugActivity::class.java))
//                return true
//            }
//            else -> {
//            }
//        }
//        return super.onOptionsItemSelected(item)
//    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, @Nullable data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_ADD
            && resultCode == RESULT_OK
        ) {
            notesAdapter.refresh(loadNotesFromDatabase())
        }
    }

    @SuppressLint("Range")
    private fun loadNotesFromDatabase(): List<com.example.homeworktodolist.beans.Note> {
        if (database == null) {
            return emptyList()
        }
        val result: MutableList<com.example.homeworktodolist.beans.Note> =
            LinkedList<com.example.homeworktodolist.beans.Note>()
        var cursor: Cursor? = null
        try {
            cursor = database!!.query(
                TodoNote.TABLE_NAME, null,
                null, null,
                null, null,
                TodoNote.COLUMN_PRIORITY + " DESC"
            )
            while (cursor.moveToNext()) {
                val id = cursor.getLong(cursor.getColumnIndex(TodoNote._ID))
                val content = cursor.getString(cursor.getColumnIndex(TodoNote.COLUMN_CONTENT))
                val dateMs = cursor.getLong(cursor.getColumnIndex(TodoNote.COLUMN_DATE))
                val intState = cursor.getInt(cursor.getColumnIndex(TodoNote.COLUMN_STATE))
                val intPriority = cursor.getInt(cursor.getColumnIndex(TodoNote.COLUMN_PRIORITY))
                val note: com.example.homeworktodolist.beans.Note =
                    com.example.homeworktodolist.beans.Note(id)
                note.setContent(content)
                note.setDate(Date(dateMs))
                note.setState(com.example.homeworktodolist.beans.State.from(intState))
                note.setPriority(com.example.homeworktodolist.beans.Priority.from(intPriority))
                result.add(note)
            }
        } finally {
            cursor?.close()
        }
        return result
    }

    private fun deleteNote(note: com.example.homeworktodolist.beans.Note) {
        if (database == null) {
            return
        }
        val rows = database!!.delete(
            TodoNote.TABLE_NAME,
            TodoNote._ID + "=?", arrayOf(note.id.toString())
        )
        if (rows > 0) {
            notesAdapter.refresh(loadNotesFromDatabase())
        }
    }

    private fun updateNode(note: com.byted.camp.todolist.beans.Note) {
        if (database == null) {
            return
        }
        val values = ContentValues()
        values.put(TodoNote.COLUMN_STATE, note.getState().intValue)
        val rows = database!!.update(
            TodoNote.TABLE_NAME, values,
            TodoNote._ID + "=?", arrayOf(note.id.toString())
        )
        if (rows > 0) {
            notesAdapter.refresh(loadNotesFromDatabase())
        }
    }

    companion object {
        private const val REQUEST_CODE_ADD = 1002
    }
}
